# DevOps & IT Admin Toolkit

Collection of real-world automation, CI/CD, and monitoring tools used in DevOps and system administration roles.

## Modules
- scripts/
- monitoring_dashboard/
- ci-cd/
- terraform/
- o365/
- firewall/