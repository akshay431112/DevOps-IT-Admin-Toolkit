# Requires Microsoft Graph API setup
print('Fetching mailbox logs...')