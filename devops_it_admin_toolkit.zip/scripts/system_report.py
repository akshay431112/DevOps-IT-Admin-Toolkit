import os
print('System report...')